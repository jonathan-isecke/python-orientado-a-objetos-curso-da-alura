from codigo.bytebank import Funcionario


ana = Funcionario('Ana', '12/03/1997', 100000000)

print(ana.calcular_bonus())
